# XBoard version 0.a
'''
    Objective: To design and develop a button-based interactive notice board.

    Description:
    ~~~~~~~~~~~
    This is a simple notice board with following functionalities:
    " Modern Notice Board X.b.1" have two modes of operation [ Kiosk Mode & Player mode ]

    Overall Pages -
        Based on overall mapping, all pages are as follows -
            00 - AICTE STUFF				X
            01 - VM							X
            02 - SL							X
            03 - Members
            04 - Achievements - 1
             X - Extra Page

    Workers -
        1. Updater.py
        2. BGM.py

    @ThrillingStar
'''

import sys, subprocess

from PyQt5.QtWidgets 	import (QApplication, QWidget, QSizePolicy,
                                QStackedLayout, QHBoxLayout, QVBoxLayout,
                                QLabel,
                                QAction)
from PyQt5.QtGui		import QPixmap
from PyQt5.QtCore		import QTimer, Qt

stylesheet = """
    QWidget {
        background-color: #000000;
        font-family: 'Quicksand';
    }
             """

class XA(QWidget):
    
    def __init__(self):
        super().__init__()
        self.initUI()
        print("All Set!")
        
    def initUI(self):
        ''' Set up the app '''
        self.setWindowTitle("XBoard AIL")
        
        print("Setting app geometry...")
        desktop = QApplication.desktop()
        rect = desktop.availableGeometry()
        self.setGeometry(rect)
        self.setMaximumSize(self.size())
        
        print("Creating Actions...")
        self.createActions()
        self.addAction(self.p0_act)
        self.addAction(self.p1_act)
        self.addAction(self.p2_act)
        self.addAction(self.p3_act)
        self.addAction(self.p4_act)
        self.addAction(self.p5_act)
        self.addAction(self.exit_act)
        
        print("Setting default font size...")
        self.font_size = '35'
        
        print("Setting up Main Window...")
        self.setUpMainWindow()
        
#         print("Starting Gesture Getter...")
#         self.g = subprocess.Popen(["python","cv-g.py"])
        
        print("Starting Updator")
        self.updater = subprocess.Popen(["python","Updater.py"])

        print("Starting BGM...")
        self.bgm = subprocess.Popen(["python","bgm.py"])
        
        print("Opening application...")
        self.showFullScreen()        
        

    def setUpMainWindow(self):
        ''' Create and arrange widgets in main window '''
        
        #Create main stack
        self.main_stack = QStackedLayout()
        
        print("Creating Main Stack Pages Widgets...")
        # Create main stack pages
        print("Creating page 0...")
        self.create_page_0()
        print("Creating page 1...")
        self.create_page_1()
        print("Creating page 2...")
        self.create_page_2()
        print("Creating page 3...")
        self.create_page_3()
        print("Creating page 4...")
        self.create_page_4()
        print("Creating page 5...")
        self.create_page_5()
        self.create_page_x()
        
        print("Adding widgets to the main stack")
        # Add page widgets to the main stack
        self.main_stack.addWidget(self.page_0)
        self.main_stack.addWidget(self.page_1)
        self.main_stack.addWidget(self.page_2)
        self.main_stack.addWidget(self.page_3)
        self.main_stack.addWidget(self.page_4)
        self.main_stack.addWidget(self.page_5)
        #self.main_stack.addWidget(self.page_x)
        
        print("Setting up main layout...")
        # Set Self Layout
        self.setLayout(self.main_stack)

        print("Starting Updater Timer...")
        # Set an Updater Timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_labels)
        self.timer.start(500)
        
        print("Starting Playlist Timer...")
        # Set playlist timer
        self.index = 0
        self.timer2 = QTimer(self)
        self.timer2.timeout.connect(self.play)
        self.timer2.start(6000)
        
    def create_page_0(self):
        ''' Create and arrange widgets in PAGE 0 '''
        # Set Size Policies for the elements
        self.sizePolicy1 = QSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        self.sizePolicy2 = QSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Expanding)
        
        # AIL Head
        head = QLabel("Enterpreneurship Ecosystem of KITS")
        head.setMinimumSize(3*self.width()//4, 0)
        head.setSizePolicy(self.sizePolicy1)
        head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: white ; background-color: #ff644d ; padding: 2px; border-top-left-radius: 10px; border-top-right-radius: 10px;")

        # Data
        self.page0_data = QLabel("The Page 1 data")
        self.page0_data.setSizePolicy(self.sizePolicy2)
        self.page0_data.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.page0_data.setWordWrap(True)
        self.page0_data.setStyleSheet(f" font-size: {int(self.font_size) - 20}pt; color: #4d0a00; background-color: #ffe6e6; padding: 10px; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;")

        # Create Main VBox
        vbox = QVBoxLayout()
        vbox.addWidget(head)
        vbox.addWidget(self.page0_data)

        vbox.setSpacing(0)
        vbox.setAlignment(Qt.AlignCenter)
        
        self.page_0 = QWidget()
        self.page_0.setLayout(vbox)
        
    
    def create_page_1(self):
        ''' Create and arrange widgets in PAGE 1 '''
        hb = QHBoxLayout()
        hb.setSpacing(0)
        hb.setContentsMargins(0,0,0,0)
        
        icon = QLabel(5*"                      ")
        icon.setStyleSheet(" border-image: url(Pics/logo.png); margin: 50px; ")
        icon.setSizePolicy(QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Minimum)
        
        # create elements for hbox
        vm = QVBoxLayout()
        vm.setSpacing(20)
        vm.setContentsMargins(0,10,50,10)
        vm.setAlignment(Qt.AlignCenter)
        
        vvbox = QVBoxLayout()
        vvbox.setSpacing(0)
        # create vm
        vision = QLabel('Vision')
        vision.setSizePolicy(self.sizePolicy1)
        vision.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: white ; background-color: #008fb3 ; padding: 2px; border-top-left-radius: 10px; border-top-right-radius: 10px;")
        
        visiond = QLabel('To Promote Economic, Social and Environmental Development by transforming Young Age Entrepreneurs Innovative Ideas into Viable/Probable Business Propositions through Vibrant Technological Ecosystem.\n')
        visiond.setAlignment(Qt.AlignmentFlag.AlignTop)
        visiond.setAlignment(Qt.AlignJustify)
        visiond.setWordWrap(True)
        visiond.setStyleSheet(f" font-size: {int(self.font_size) - 12}pt; font-weight: bold; color: #005266; background-color: #ccf5ff; padding: 20px; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;")

        vvbox.addWidget(vision)
        vvbox.addWidget(visiond)
        
        mvbox = QVBoxLayout()
        mvbox.setSpacing(0)
        mission = QLabel('Mission')
        mission.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: white ; background-color: #ff644d ; padding: 2px; border-top-left-radius: 10px; border-top-right-radius: 10px;")
        
        missiond = QLabel('Description')
        missiond.setText('\
1. To provide a Robust Ecosystem by imparting Knowledge partnership between Industry, Academia and Alumni. \n\n\
2. Facilitate and support students for collaborative or Multidisciplinary Research through exchange of Innovative Ideas or thoughts.  \n\n\
3. To provide Pre-Incubation and Incubation facility to nurture ideas into prototypes and Products. \n \
                         ')
        missiond.setAlignment(Qt.AlignTop)
        missiond.setAlignment(Qt.AlignJustify)
        missiond.setWordWrap(True)
        missiond.setStyleSheet(f"font-size: {int(self.font_size) - 12}pt; font-weight: bold; color: #4d0a00; background-color: #ffe6e6; padding: 20px;  border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;")
        
        mvbox.addWidget(mission)
        mvbox.addWidget(missiond)
        
        vm.addLayout(vvbox)
        vm.addLayout(mvbox)
        
        vmw = QWidget()
        vmw.setLayout(vm)
        
        hb.addWidget(icon)
        hb.addWidget(vmw)
        
        self.page_1 = QWidget()
        self.page_1.setLayout(hb)
        self.page_1.setStyleSheet("background-color: white;") 
    
    def create_page_2(self):
        ''' Create and arrange widgets in PAGE 2 '''
        
        sl = QHBoxLayout()
        sl.setSpacing(0)
        
        svbox = QVBoxLayout()
        svbox.setSpacing(0)
        
        stg = QLabel('Short Term Goals')
        stg.setAlignment(Qt.AlignCenter)
        stg.setSizePolicy(self.sizePolicy1)
        stg.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: white ; background-color: #008fb3 ; padding: 2px; border-top-left-radius: 10px; border-top-right-radius: 0px;")

        self.stgd = QLabel('Description')
        self.stgd.setSizePolicy(self.sizePolicy2)
        self.stgd.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.stgd.setWordWrap(True)
        self.stgd.setStyleSheet(f" font-size: {int(self.font_size) - 20}pt; color: #005266; background-color: #ccf5ff; padding: 10px; border-bottom-left-radius: 10px; border-bottom-right-radius: 0px;")
        
        svbox.addWidget(stg)
        svbox.addWidget(self.stgd)
        
        lvbox = QVBoxLayout()
        lvbox.setSpacing(0)
        
        ltg = QLabel('Long Term Goals')
        ltg.setAlignment(Qt.AlignCenter)
        ltg.setSizePolicy(self.sizePolicy1)
        ltg.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: white ; background-color: #ff644d ; padding: 2px; border-top-left-radius: 0px; border-top-right-radius: 10px;")

        self.ltgd = QLabel('Description')
        self.ltgd.setSizePolicy(self.sizePolicy2)
        self.ltgd.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.ltgd.setWordWrap(True)
        self.ltgd.setStyleSheet(f" font-size: {int(self.font_size) - 20}pt; color: #4d0a00; background-color: #ffe9e6; padding: 10px; border-bottom-left-radius: 0px; border-bottom-right-radius: 10px;")
        
        lvbox.addWidget(ltg)
        lvbox.addWidget(self.ltgd)
        
        sl.addLayout(svbox)
        sl.addLayout(lvbox)
        
        self.setPage2()
        
        self.page_2 = QWidget()
        self.page_2.setLayout(sl)
    
    def create_page_3(self):
        ''' Create and arrange widgets in PAGE 3 '''
        print("Creating page-3 header...")
        # Members Head
        head = QLabel("Committee Members")
        head.setMinimumSize(3*self.width()//4, 0)
        head.setSizePolicy(self.sizePolicy1)
        head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: #eeeeee ; background-color: #444444 ; padding: 2px;")

        # Data
        images = QHBoxLayout()
        images.setSpacing(30)
        images.setContentsMargins(30,10,30,10)
        
        img1 = QLabel(5*"                      ")
        img2 = QLabel(5*"                      ")
        img3 = QLabel(5*"                      ")
        
        print("Loading slide1 data...")
        img1.setStyleSheet("border-image: url(Pics/ailppt/Slide1.PNG); border-radius: 10px;")
        print("Loading slide2 data...")
        img2.setStyleSheet("border-image: url(Pics/ailppt/Slide2.PNG); border-radius: 10px;")
        print("Loading slide3 data...")
        img3.setStyleSheet("border-image: url(Pics/ailppt/Slide3.PNG); border-radius: 10px;")
        
        img1.setSizePolicy(QSizePolicy.Policy.Minimum,QSizePolicy.Expanding)
        
        print("Adding images to the hbox...")
        images.addWidget(img1)
        images.addWidget(img2)
        images.addWidget(img3)
        
        print("Combining header and images...")
        # Create Main VBox
        vbox = QVBoxLayout()
        vbox.setContentsMargins(0,0,0,0)
        vbox.addWidget(head)
        vbox.addLayout(images)

        vbox.setSpacing(0)
        #vbox.setAlignment(Qt.AlignCenter)
        
        print("Creating page-3 widget...")
        self.page_3 = QWidget()
        self.page_3.setLayout(vbox)
        print("Page 3 is set...")
        
    def create_page_4(self):
        ''' Create and arrange widgets in PAGE 4 '''        
        # Achievements Head
        head = QLabel("Student Achievements")
        head.setMinimumSize(3*self.width()//4, 0)
        head.setSizePolicy(self.sizePolicy1)
        head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: white ; background-color: #ff644d ; padding: 2px; border-top-left-radius: 10px; border-top-right-radius: 10px;")

        # Data
        self.page4_data = QLabel("The Page 4 data")
        self.page4_data.setSizePolicy(self.sizePolicy2)
        self.page4_data.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.page4_data.setWordWrap(True)
        self.page4_data.setStyleSheet(f" font-size: {int(self.font_size) - 20}pt; color: #4d0a00; background-color: #ffe6e6; padding: 10px; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;")

        # Create Main VBox
        vbox = QVBoxLayout()
        vbox.addWidget(head)
        vbox.addWidget(self.page4_data)

        vbox.setSpacing(0)
        vbox.setAlignment(Qt.AlignCenter)
        
        self.page_4 = QWidget()
        self.page_4.setLayout(vbox)
        
    def create_page_5(self):
        ''' Create and arrange widgets in PAGE 5 '''        
        # Achievements Head
        head = QLabel("Council Achievements")
        head.setMinimumSize(3*self.width()//4, 0)
        head.setSizePolicy(self.sizePolicy1)
        head.setAlignment(Qt.AlignmentFlag.AlignCenter)
        head.setStyleSheet(f"font-size: {int(self.font_size)+5}pt; color: white ; background-color: #008fb3 ; padding: 2px; border-top-left-radius: 10px; border-top-right-radius: 10px;")

        # Data
        self.page5_data = QLabel("The Page 5 data")
        #self.setUpdates()
        self.page5_data.setSizePolicy(self.sizePolicy2)
        self.page5_data.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.page5_data.setWordWrap(True)
        self.page5_data.setStyleSheet(f" font-size: {int(self.font_size) - 20}pt; color: #005266; background-color: #ccf5ff; padding: 10px; border-bottom-left-radius: 10px; border-bottom-right-radius: 10px;")

        # Create Main VBox
        vbox = QVBoxLayout()
        vbox.addWidget(head)
        vbox.addWidget(self.page5_data)

        vbox.setSpacing(0)
        vbox.setAlignment(Qt.AlignCenter)
        
        self.page_5 = QWidget()
        self.page_5.setLayout(vbox)
        
    def create_page_x(self):
        ''' Create and arrange widgets in PAGE 5 '''
        pass

########################################################################################
# Creation of Actions
########################################################################################

    def createActions(self):
        ''' Create actions for app '''
        
        self.p0_act = QAction('&P0')
        self.p0_act.setShortcut('0')
        self.p0_act.triggered.connect(lambda: (self.main_stack.setCurrentIndex(0),self.keyPressed('0')))
        
        self.p1_act = QAction('&P1')
        self.p1_act.setShortcut('1')
        self.p1_act.triggered.connect(lambda: (self.main_stack.setCurrentIndex(1),self.keyPressed('1')))
        
        self.p2_act = QAction('&P2')
        self.p2_act.setShortcut('2')
        self.p2_act.triggered.connect(lambda: (self.main_stack.setCurrentIndex(2),self.keyPressed('2')))
        
        self.p3_act = QAction('&P3')
        self.p3_act.setShortcut('3')
        self.p3_act.triggered.connect(lambda: (self.main_stack.setCurrentIndex(3),self.keyPressed('3')))
        
        self.p4_act = QAction('&P4')
        self.p4_act.setShortcut('4')
        self.p4_act.triggered.connect(lambda: (self.main_stack.setCurrentIndex(4),self.keyPressed('4')))
        
        self.p5_act = QAction('&P5')
        self.p5_act.setShortcut('5')
        self.p5_act.triggered.connect(lambda: (self.main_stack.setCurrentIndex(5),self.keyPressed('5')))
        
        self.exit_act = QAction('&Exit')
        self.exit_act.setShortcut('-')
        self.exit_act.triggered.connect(self.close)
        
########################################################################################
# Update Labels
########################################################################################

    def setPage0(self):
        ''' Update page 0 (ecosystem) '''
        #print("Updating page 0...")
        with open("rss/ecosystem.txt",'r') as f:
            text = f.read()
            self.page0_data.setText(text)
    
    def setPage2(self):
        ''' Update page 2 STGs-LTGs '''
        #print("Updating page 2...")
        
        #print("Updating stgs...")
        with open("rss/stg.txt",'r') as f:
            text = f.read()
            self.stgd.setText(text)
        
        #print("Updating ltgs...")
        with open("rss/ltg.txt",'r') as f:
            text = f.read()
            self.ltgd.setText(text)
        
    def setPage4(self):
        ''' Update page 4 Student Achievements '''
        #print("Updating page 4...")
        with open("rss/s-achievements.txt",'r') as f:
            text = f.read()
            self.page4_data.setText(text)
            
    def setPage5(self):
        ''' Update page 5 Council Achievements '''
        #print("Updating page 5...")
        with open("rss/achievements.txt",'r') as f:
            text = f.read()
            self.page5_data.setText(text)
            
    def setPage(self):
        ''' Check for any gesture '''
        with open("g.txt",'r') as f:
            gesture = f.read()
            try:
                if 0 <= int(gesture) <= 5: 
                    self.main_stack.setCurrentIndex(int(gesture))
                    self.timer2.stop()
                    QTimer.singleShot(5000, self.timer2.start)  # 5 seconds
            except:
                pass
            
########################################################################################
# Update Labels
########################################################################################

    def update_labels(self):
        ''' Update the data '''
        try:            
            self.setPage0()
            self.setPage4()
            self.setPage5()
            self.setPage()

        except Exception as e:
            print(f'Error in update_labels: {e}')
        
########################################################################################
# Play Contents
########################################################################################

    def play(self):
        ''' Play Playlist '''        
        self.playlist = [0,1,2,4,5]
        self.main_stack.setCurrentIndex(self.playlist[self.index])

        self.index+=1
        if self.index == 5:
            self.index = 0
            
########################################################################################
# Key Press Event
########################################################################################

    def keyPressed(self,key):
        ''' Open Menu Page if any key press is detected '''
        print(key,'pressed...')
        
        self.timer2.stop()
        QTimer.singleShot(30000, self.timer2.start)  # 30 seconds
        
    def keyPressEvent(self,event):
        ''' Open Menu Page if any key press is detected '''
        key = event.key()
        print(key,'key pressed...')
        
        self.main_stack.setCurrentIndex(1)
        
        self.timer2.stop()
        QTimer.singleShot(30000, self.timer2.start)  # 30 seconds
        
        super().keyPressEvent(event)
        
########################################################################################
# Close Event
########################################################################################

    def closeEvent(self,event):
        ''' Close Event '''
        self.timer.stop()
        self.timer2.stop()

        self.updater.terminate()
        self.updater.communicate()

        self.bgm.terminate()
        self.bgm.communicate()
        
        #self.g.terminate()
        #self.g.communicate()

        event.accept()
    
if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setStyleSheet(stylesheet)
    window = XA()
    sys.exit(app.exec())
