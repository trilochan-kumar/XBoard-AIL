#!/bin/bash
# XLauncher.sh
# Navigate to home directory, 
# Then to program directory, 
# And then execute the python script.

cd /
cd /home/thrillu/Desktop/AIL-G
python3 xboard-a-b.py
cd /