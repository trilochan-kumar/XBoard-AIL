import feedparser
import time
import socket
import threading

class RssThread(threading.Thread):
    def __init__(self, rss_url, file_name):
        self.rss_url = rss_url
        self.file_name = file_name
        super().__init__()

    def run(self):
        while True:
            # Get Previous contents
            with open(self.file_name, 'r') as file:
                prev_contents = file.read()

            try:
                feed = feedparser.parse(self.rss_url)
                if feed.entries:
                    with open(self.file_name, 'w') as file:
                        for entry in feed.entries:
                            file.write('<h2>' + entry.title + '</h2>'+'<p>'+entry.description+'</p>'+'<hr>')
                #print("Success")
                            
            except:
                with open(self.file_name, 'w') as file:
                    file.write(prev_contents)
            

rss_links = [
        ('https://1-ecosystem.blogspot.com/feeds/posts/default?alt=rss', 'rss/ecosystem.txt'),
        ('https://4-achievements.blogspot.com/feeds/posts/default?alt=rss', 'rss/achievements.txt'),
        ('https://5-acheivements.blogspot.com/feeds/posts/default?alt=rss', 'rss/s-achievements.txt')
            ]

num = 10

threads = [RssThread(*link) for link in rss_links]
for thread in threads:
    thread.start()
